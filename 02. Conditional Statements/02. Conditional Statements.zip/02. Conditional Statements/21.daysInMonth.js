function printMonthsDays(month) {
  let days = 0;

  days = new Date(2023, month, 0).getDate();

  console.log(days);
}

printMonthsDays(1);
printMonthsDays(2);
printMonthsDays(3);
printMonthsDays(4);
printMonthsDays(5);
printMonthsDays(6);
printMonthsDays(7);
printMonthsDays(8);
printMonthsDays(9);
printMonthsDays(10);
printMonthsDays(11);
printMonthsDays(12);
