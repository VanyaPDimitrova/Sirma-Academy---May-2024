function isExcellent(rating) {
  if (rating >= 5.50) {
    console.log('Excellent!');
  } 
}

isExcellent(6);
isExcellent(5);
isExcellent(5.5);
isExcellent(5.51);
isExcellent(5.501);
