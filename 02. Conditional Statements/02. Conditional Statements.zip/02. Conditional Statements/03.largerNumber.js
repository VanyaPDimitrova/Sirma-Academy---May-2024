function largerNumber(number1, number2) {
  if (number1 > number2) {
    console.log(number1);
  } else {
    console.log(number2);
  }
}

largerNumber(2, 4);
largerNumber(7, 12);
largerNumber(-1, -5);
