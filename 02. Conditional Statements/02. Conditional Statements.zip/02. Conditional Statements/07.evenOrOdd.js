function isEven(number) {
  if (number % 2 == 0) {
    console.log('even');
  } else {
    console.log('odd');
  }
}

isEven(0);
isEven(2);
isEven(-5);
isEven(1024);
isEven(42);
isEven(333);
